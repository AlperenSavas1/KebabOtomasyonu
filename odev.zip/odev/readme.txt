Projenin Adı: Kebap ve FastFood Zinciri

Projenin Amacı: Kebap Ve Fastfood zinciri olan bu restoran için
	paket siparişi almak ve fatura halinde bunu bastırmak
